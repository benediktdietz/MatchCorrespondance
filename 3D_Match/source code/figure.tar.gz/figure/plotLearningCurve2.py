import os
import sys
import subprocess
import pandas as pd
import matplotlib.pylab as plt
from numpy import array
import numpy as np

traindir = 'trainloss.txt'
testdir = 'testloss.txt'

with open(traindir, 'r') as f:
    f = f.readlines()
trainall = []
for line in f:
    line = line.split() 
    trainall.append(line)

trainall = array(trainall).astype(float)

with open(testdir, 'r') as f:
    f = f.readlines()
testall = []
for line in f:
    line = line.split() 
    testall.append(line)

testall = array(testall)[:,[0,2,3]].astype(float)

train_iter = trainall[:,0]
matchloss = trainall[:,1]
nonmatchloss = trainall[:,2]

test_iter = testall[::4,0]

overall = testall[::4,2]
trunk = testall[1::4,2]
branch = testall[2::4,2]
leaves = testall[3::4,2]

fig,ax1 = plt.subplots(figsize=(8,6))
matchloss_curve, = ax1.plot(train_iter,matchloss, color='red', alpha=.8, linewidth=1.5)
nonmatchloss_curve, = ax1.plot(train_iter,nonmatchloss, color='green', alpha=.8, linewidth=1.5)

ax1.set_ylim(ymin=0,ymax=1)
ax1.set_xlabel('Iteration', fontsize=15)
ax1.set_ylabel('Loss', fontsize=15)
ax1.tick_params(labelsize=15)
ax1.set_axis_bgcolor('white')
ax1.grid(b=False)

ax2 = ax1.twinx()

error_overall, = ax2.plot(test_iter, overall, color='blue', alpha=.8, linewidth=3)
error_trunk, =  ax2.plot(test_iter, trunk, color='pink', alpha=.8, linewidth=3)
error_branch, = ax2.plot(test_iter, branch, color='black', alpha=.8, linewidth=3)
error_leaves, = ax2.plot(test_iter, leaves, color='purple', alpha=.8, linewidth=3)


ax2.set_ylabel('Error rate', fontsize=15)
ax2.set_ylim(ymin=0,ymax=80)
ax2.tick_params(labelsize=15)

legend = plt.legend((matchloss_curve,nonmatchloss_curve,error_overall,error_trunk,error_branch,error_leaves),('matchloss','nonmatchloss','error for overall samples','error for trunk','error for branch','error for leaves'))

frame = legend.get_frame()

frame.set_facecolor('white')
frame.set_edgecolor('black')
plt.title('Training Curve', fontsize=18)
plt.show()
